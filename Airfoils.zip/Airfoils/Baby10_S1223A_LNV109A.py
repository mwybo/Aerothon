from Aerothon.ACAirfoil import ACAirfoil
import os

Baby10_S1223A_LNV109A = ACAirfoil('Baby10_S1223A_LNV109A', fext = '.txt', nalpha = 20)

if __name__ == '__main__':
    import pylab as pyl
    #
    # Plot the polars and the airfoil
    #
    Baby10_S1223A_LNV109A.PlotPolar()
    Baby10_S1223A_LNV109A.PlotAirfoil(fig=2)
    pyl.show()
