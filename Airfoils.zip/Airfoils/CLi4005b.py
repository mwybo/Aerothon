from Aerothon.ACAirfoil import ACAirfoil
import os

CLi4005b = ACAirfoil('CLi4005b', fext = '.txt', nalpha = 20)

if __name__ == '__main__':
    import pylab as pyl
    #
    # Plot the polars and the airfoil
    #
    CLi4005b.PlotPolar()
    CLi4005b.PlotAirfoil(fig=2)
    pyl.show()
