from Aerothon.ACAirfoil import ACAirfoil
import os

DFS03 = ACAirfoil('DFS03', fext = '.txt', nalpha = 20)

if __name__ == '__main__':
    import pylab as pyl
    #
    # Plot the polars and the airfoil
    #
    DFS03.PlotPolar()
    DFS03.Plot2DPolar(fig=2)
    DFS03.PlotAirfoil(fig=3)
    pyl.show()
