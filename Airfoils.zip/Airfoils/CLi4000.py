from Aerothon.ACAirfoil import ACAirfoil
import os

CLi4000 = ACAirfoil('CLi4000', fext = '.txt', nalpha = 20)

if __name__ == '__main__':
    import pylab as pyl
    #
    # Plot the polars and the airfoil
    #
    CLi4000.PlotPolar()
    CLi4000.PlotAirfoil(fig=2)
    pyl.show()
