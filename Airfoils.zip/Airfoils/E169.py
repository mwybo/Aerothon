from Aerothon.ACAirfoil import ACAirfoil
import os

E169 = ACAirfoil('E169', fext = '.txt', nalpha = 20)

if __name__ == '__main__':
    import pylab as pyl
    #
    # Plot the polars and the airfoil
    #
    E169.PlotPolar(fig=1)
    E169.Plot2DPolar(fig=2)
    E169.PlotAirfoil(fig=3)
    pyl.show()
