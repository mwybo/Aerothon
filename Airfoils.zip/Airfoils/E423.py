from Aerothon.ACAirfoil import ACAirfoil
import os

E423 = ACAirfoil('E423', fext = '.txt', nalpha = 20)

if __name__ == '__main__':
    import pylab as pyl
    #
    # Plot the polars and the airfoil
    #
    E423.PlotPolar()
    E423.PlotAirfoil(fig=2)
    pyl.show()
